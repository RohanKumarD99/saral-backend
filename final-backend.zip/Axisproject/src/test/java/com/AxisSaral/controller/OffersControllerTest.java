//package com.AxisSaral.controller;
//
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//
//import com.AxisSaral.model.Offers;
//
//@RunWith(SpringRunner.class)
//@WebMvcTest(OffersController.class)
//class OffersControllerTest {
//	
//	@Autowired
//	private MockMvc mockMvc;
//	
//	@MockBean
//	private OffersController offersController;
//	
//	@Test
//	public void list() throws Exception {
//		Offers offers = new Offers();
//		offers.setTitle("testtitle");
//		offers.setValidtill("testvalidtill");
//		offers.setDescription("testdescription");
//		
//		List allOffers = List(offers);
//		
//		given(offersController.list()).willReturn(allOffers);
//		
//		mockMvc.perform(get())
//		
//	}
//
//
//}
