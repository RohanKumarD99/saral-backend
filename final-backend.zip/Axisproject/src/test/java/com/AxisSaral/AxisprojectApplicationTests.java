package com.AxisSaral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxisprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
