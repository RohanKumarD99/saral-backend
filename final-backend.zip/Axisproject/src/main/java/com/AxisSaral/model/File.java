package com.AxisSaral.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class File {

	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long id;

	    private String fileName;

	    private String uploadedBy;

	    private boolean isApproved;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		public String getUploadedBy() {
			return uploadedBy;
		}

		public void setUploadedBy(String uploadedBy) {
			this.uploadedBy = uploadedBy;
		}

		public boolean isApproved() {
			return isApproved;
		}

		public void setApproved(boolean isApproved) {
			this.isApproved = isApproved;
		}

		public File(Long id, String fileName, String uploadedBy, boolean isApproved) {
			super();
			this.id = id;
			this.fileName = fileName;
			this.uploadedBy = uploadedBy;
			this.isApproved = isApproved;
		}

		public File() {
			super();
		}
	    
	    
}
