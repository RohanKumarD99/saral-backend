package com.AxisSaral.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class LeaveApply {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	private String from;
	private String description;
	private String fromdate;
	private String todate;
	private String typeofleave;
	public LeaveApply() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LeaveApply(long id, String from, String description, String fromdate, String todate, String typeofleave) {
		super();
		this.id = id;
		this.from = from;
		this.description = description;
		this.fromdate = fromdate;
		this.todate = todate;
		this.typeofleave = typeofleave;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFromdate() {
		return fromdate;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}
	public String getTodate() {
		return todate;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	public String getTypeofleave() {
		return typeofleave;
	}
	public void setTypeofleave(String typeofleave) {
		this.typeofleave = typeofleave;
	}
}