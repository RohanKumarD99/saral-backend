package com.AxisSaral.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Project {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	private String projecttitle;
	private String projectdescription;
	private String projectmanager;
	private String projectdomain;
	private String stakeholdername;
	private String stakeholdertype;
	private String stakeholderid;
	private String stakeholderdepartment;
	private String applicationname;
	private String applicationowner;
	private String applicationtype;
	private String modulename;
	private String moduleowner;
	private String moduletype;
	private String noofmodules;
	private String teamname;
	private String noofteams;
	private String teamsize;
	private String jobid;
	private String jobtitle;
	private String jobdescription;
	private String skillsrequired;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getProjecttitle() {
		return projecttitle;
	}
	public void setProjecttitle(String projecttitle) {
		this.projecttitle = projecttitle;
	}
	public String getProjectdescription() {
		return projectdescription;
	}
	public void setProjectdescription(String projectdescription) {
		this.projectdescription = projectdescription;
	}
	public String getProjectmanager() {
		return projectmanager;
	}
	public void setProjectmanager(String projectmanager) {
		this.projectmanager = projectmanager;
	}
	public String getProjectdomain() {
		return projectdomain;
	}
	public void setProjectdomain(String projectdomain) {
		this.projectdomain = projectdomain;
	}
	public String getStakeholdername() {
		return stakeholdername;
	}
	public void setStakeholdername(String stakeholdername) {
		this.stakeholdername = stakeholdername;
	}
	public String getStakeholdertype() {
		return stakeholdertype;
	}
	public void setStakeholdertype(String stakeholdertype) {
		this.stakeholdertype = stakeholdertype;
	}
	public String getStakeholderid() {
		return stakeholderid;
	}
	public void setStakeholderid(String stakeholderid) {
		this.stakeholderid = stakeholderid;
	}
	public String getStakeholderdepartment() {
		return stakeholderdepartment;
	}
	public void setStakeholderdepartment(String stakeholderdepartment) {
		this.stakeholderdepartment = stakeholderdepartment;
	}
	public String getApplicationname() {
		return applicationname;
	}
	public void setApplicationname(String applicationname) {
		this.applicationname = applicationname;
	}
	public String getApplicationowner() {
		return applicationowner;
	}
	public void setApplicationowner(String applicationowner) {
		this.applicationowner = applicationowner;
	}
	public String getApplicationtype() {
		return applicationtype;
	}
	public void setApplicationtype(String applicationtype) {
		this.applicationtype = applicationtype;
	}
	public String getModulename() {
		return modulename;
	}
	public void setModulename(String modulename) {
		this.modulename = modulename;
	}
	public String getModuleowner() {
		return moduleowner;
	}
	public void setModuleowner(String moduleowner) {
		this.moduleowner = moduleowner;
	}
	public String getModuletype() {
		return moduletype;
	}
	public void setModuletype(String moduletype) {
		this.moduletype = moduletype;
	}
	public String getNoofmodules() {
		return noofmodules;
	}
	public void setNoofmodules(String noofmodules) {
		this.noofmodules = noofmodules;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}
	public String getNoofteams() {
		return noofteams;
	}
	public void setNoofteams(String noofteams) {
		this.noofteams = noofteams;
	}
	public String getTeamsize() {
		return teamsize;
	}
	public void setTeamsize(String teamsize) {
		this.teamsize = teamsize;
	}
	public String getJobid() {
		return jobid;
	}
	public void setJobid(String jobid) {
		this.jobid = jobid;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	public String getJobdescription() {
		return jobdescription;
	}
	public void setJobdescription(String jobdescription) {
		this.jobdescription = jobdescription;
	}
	public String getSkillsrequired() {
		return skillsrequired;
	}
	public void setSkillsrequired(String skillsrequired) {
		this.skillsrequired = skillsrequired;
	}
	
	public Project(long id, String projecttitle, String projectdescription, String projectmanager, String projectdomain,
			String stakeholdername, String stakeholdertype, String stakeholderid, String stakeholderdepartment,
			String applicationname, String applicationowner, String applicationtype, String modulename,
			String moduleowner, String moduletype, String noofmodules, String teamname, String noofteams,
			String teamsize, String jobid, String jobtitle, String jobdescription, String skillsrequired) {
		super();
		this.id = id;
		this.projecttitle = projecttitle;
		this.projectdescription = projectdescription;
		this.projectmanager = projectmanager;
		this.projectdomain = projectdomain;
		this.stakeholdername = stakeholdername;
		this.stakeholdertype = stakeholdertype;
		this.stakeholderid = stakeholderid;
		this.stakeholderdepartment = stakeholderdepartment;
		this.applicationname = applicationname;
		this.applicationowner = applicationowner;
		this.applicationtype = applicationtype;
		this.modulename = modulename;
		this.moduleowner = moduleowner;
		this.moduletype = moduletype;
		this.noofmodules = noofmodules;
		this.teamname = teamname;
		this.noofteams = noofteams;
		this.teamsize = teamsize;
		this.jobid = jobid;
		this.jobtitle = jobtitle;
		this.jobdescription = jobdescription;
		this.skillsrequired = skillsrequired;
	}
	
	public Project() {
		super();
	}	
		
}
