package com.AxisSaral.controller;

import java.util.List;

import com.AxisSaral.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.AxisSaral.model.Project;
import com.AxisSaral.service.ProjectService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/project")
public class ProjectController {

	@Autowired
	ProjectService projectService;

	@Autowired
	ProjectRepository projectRepository;
	
	@PostMapping("/submitproject")
	private String add(@RequestBody Project project) {
		projectService.save(project);
		return "Project Uploaded successful";
	}

	@GetMapping("/getAllprojects")
	public ResponseEntity<List<Project>> getAll() {
		return ResponseEntity.ok(projectRepository.findAll());
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<Project> findById(@PathVariable Long id) {
		return ResponseEntity.ok(projectRepository.findById(id).orElse(null));
	}

}
