package com.AxisSaral.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.AxisSaral.RequestDTO.FileApprovalRequestDTO;
import com.AxisSaral.RequestDTO.FileDownloadRequestDTO;
import com.AxisSaral.ResponseDTO.FileDownloadResponseDTO;
import com.AxisSaral.repository.FileRepository;
import com.AxisSaral.service.FileService;

@CrossOrigin
@RestController
@RequestMapping("file")
public class FileController {

    @Autowired
    private FileRepository fileRepository;
    
    @Autowired
    private FileService fileService;

    @PostMapping("/upload")
    public ResponseEntity<?> handleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam("uploadedBy") String uploadedBy ) {
        String fileName = file.getOriginalFilename();
        try {
            file.transferTo( new File("C:\\upload\\" + fileName));
            com.AxisSaral.model.File file1 = new com.AxisSaral.model.File();
            file1.setFileName(fileName);
            file1.setApproved(false);
            file1.setUploadedBy(uploadedBy);
            com.AxisSaral.model.File savedFile = fileRepository.save(file1);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); }
        return ResponseEntity.ok("File uploaded successfully.");
    }

    @GetMapping("/getFiles")
    public ResponseEntity<?> getAllFiles(){
        List<com.AxisSaral.model.File> files = fileRepository.findAll().stream().filter(
                file -> !file.isApproved()
        ).toList();

        return new ResponseEntity<>(files,HttpStatus.OK);

    }

    @PostMapping("/sendApproval")
    public ResponseEntity<?> sendApproval(@RequestBody FileApprovalRequestDTO fileApprovalRequestDTO){
        com.AxisSaral.model.File foundFile = fileRepository.findAll().stream().filter(
                file -> file.getId().equals(Long.valueOf(fileApprovalRequestDTO.getId()))
        ).findFirst().get();
        foundFile.setApproved(true);
        fileRepository.save(foundFile);

        List<com.AxisSaral.model.File> files = fileRepository.findAll().stream().filter(
                file -> !file.isApproved()
        ).toList();

        return new ResponseEntity<>(files,HttpStatus.OK);
    }

    @PostMapping("/sendRejection")
    public ResponseEntity<?> sendRejection(@RequestBody FileApprovalRequestDTO fileApprovalRequestDTO){

        fileRepository.deleteById(Long.valueOf(fileApprovalRequestDTO.getId()));

        List<com.AxisSaral.model.File> files = fileRepository.findAll().stream().filter(
                file -> !file.isApproved()
        ).toList();

        return new ResponseEntity<>(files,HttpStatus.OK);
    }

    @GetMapping("/getApprovedFiles")
    public ResponseEntity<?> getApprovedFiles(){
        List<com.AxisSaral.model.File> files = fileRepository.findAll().stream().filter(
                com.AxisSaral.model.File::isApproved
        ).toList();

        return new ResponseEntity<>(files,HttpStatus.OK);

    }
    
    
    @GetMapping("/files/{id}")
    public ResponseEntity<String> getFile(@PathVariable Long id) {
    	com.AxisSaral.model.File file = fileService.getFile(id).get();

      return ResponseEntity.ok()
    		  .contentType(MediaType.parseMediaType("application/pdf"))
          .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFileName() + "\"")
          .body(file.getFileName());
    }


}