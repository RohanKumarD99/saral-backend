package com.AxisSaral.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AxisSaral.model.LeaveApply;
import com.AxisSaral.model.Project;
import com.AxisSaral.repository.LeaveapplyRepository;
import com.AxisSaral.repository.ProjectRepository;
import com.AxisSaral.service.LeaveapplyService;
import com.AxisSaral.service.ProjectService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/leave")
public class LeaveapplyController {

	@Autowired
	LeaveapplyService leaveapplyService;

	@Autowired
	LeaveapplyRepository leaveapplyRepository;
	
	@PostMapping("/submitleave")
	private String add(@RequestBody LeaveApply leaveapply) {
		leaveapplyService.save(leaveapply);
		return "Leave Applied successful";
	}

	@GetMapping("/getAllleaves")
	public ResponseEntity<List<LeaveApply>> getAll() {
		return ResponseEntity.ok(leaveapplyRepository.findAll());
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<LeaveApply> findById(@PathVariable Long id) {
		return ResponseEntity.ok(leaveapplyRepository.findById(id).orElse(null));
	}
}