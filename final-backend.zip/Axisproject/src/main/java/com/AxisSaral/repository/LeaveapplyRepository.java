package com.AxisSaral.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AxisSaral.model.LeaveApply;

@Repository
public interface LeaveapplyRepository extends JpaRepository <LeaveApply, Long> {

}