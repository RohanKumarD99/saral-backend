package com.AxisSaral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AxisprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AxisprojectApplication.class, args);
	}

}
