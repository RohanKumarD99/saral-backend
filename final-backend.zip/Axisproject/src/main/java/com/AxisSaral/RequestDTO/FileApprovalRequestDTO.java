package com.AxisSaral.RequestDTO;

public class FileApprovalRequestDTO {
	
	private String Id;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public FileApprovalRequestDTO(String id) {
		super();
		Id = id;
	}

	public FileApprovalRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
