package com.AxisSaral.RequestDTO;

public class FileDownloadRequestDTO {
	
	private String Id;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public FileDownloadRequestDTO(String id) {
		super();
		Id = id;
	}

	public FileDownloadRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}	
	
}
