package com.AxisSaral.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AxisSaral.model.LeaveApply;
import com.AxisSaral.repository.LeaveapplyRepository;

@Service
public class LeaveapplyServiceImpl implements LeaveapplyService {

	@Autowired
	private LeaveapplyRepository leaveapplyRepository;
	
	public LeaveApply save(LeaveApply leaveapply) {
		return leaveapplyRepository.save(leaveapply);
	}
	
	public List<LeaveApply> getprofile() {
		return leaveapplyRepository.findAll();
	}

	@Override
	public List<LeaveApply> getAll() {
		// TODO Auto-generated method stub
		return null;
	}
}