package com.AxisSaral.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AxisSaral.model.File;
import com.AxisSaral.model.Newsfeed;
import com.AxisSaral.repository.FileRepository;

@Service
public class FileService {
	
	@Autowired
	private FileRepository fileRepository;
	
	public Optional<File> getFile(Long fileId) {
        return fileRepository.findById(fileId);
    }

}
