package com.AxisSaral.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AxisSaral.model.Offers;
import com.AxisSaral.repository.OffersRepository;

@Service
public class OffersServiceImpl implements OffersService{

	@Autowired
	private OffersRepository offerRepository;

	public Offers save(Offers offers) {
		return offerRepository.save(offers);
	}
	
	public List<Offers> getprofile() {
		return offerRepository.findAll();
	}
	@Override
	public List<Offers> getAll() {
		return null;
}
	
}