package com.AxisSaral.service;

import java.util.List;

import com.AxisSaral.model.Project;


public interface ProjectService {

	public Project save(Project project);
	public List<Project> getprofile();
	public List<Project> getAll();
}
