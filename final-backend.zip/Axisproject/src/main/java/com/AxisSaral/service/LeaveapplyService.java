package com.AxisSaral.service;

import java.util.List;

import com.AxisSaral.model.LeaveApply;

public interface LeaveapplyService {

	public LeaveApply save(LeaveApply leaveapply);
	public List<LeaveApply> getprofile();
	public List<LeaveApply> getAll();
}