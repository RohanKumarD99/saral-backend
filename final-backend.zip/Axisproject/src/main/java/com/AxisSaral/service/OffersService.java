package com.AxisSaral.service;

import java.util.List;

import com.AxisSaral.model.Offers;
import com.AxisSaral.model.Register;

public interface OffersService {

	public Offers save(Offers offer);
	public List<Offers> getprofile();
	public List<Offers> getAll();
}