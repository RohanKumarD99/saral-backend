package com.AxisSaral.ResponseDTO;

import org.springframework.core.io.Resource;

public class FileDownloadResponseDTO {
	
	private Resource resource;
	private String filename;
	
	public Resource getResource() {
		return resource;
	}
	public void setResource(Resource resource) {
		this.resource = resource;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	public FileDownloadResponseDTO(Resource resource, String filename) {
		super();
		this.resource = resource;
		this.filename = filename;
	}
	
	public FileDownloadResponseDTO() {
		super();
	}	

}
